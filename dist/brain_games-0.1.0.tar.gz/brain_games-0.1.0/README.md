### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vlad-i-mir70/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Vlad-i-mir70/python-project-49/actions)
<a href="https://codeclimate.com/github/Vlad-i-mir70/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4beb700ac7eb4b5276a3/maintainability" /></a>


**Пакет с игрой  "Игры Разума".**

Состоит из пяти игр:

1. Проверка на четность

[Установка и пример игры](https://asciinema.org/connect/c2632bd1-75f7-4c38-86a4-2f504d480fb4)


2. Калькулятор

[Установка и пример игры](https://asciinema.org/a/oU86oxwsoDE3RdA5LsRWaCYId)

3. Наибольший общий делитель (НОД)

[Установка и пример игры](https://asciinema.org/a/lm8qZNIo2KNJKMzUX2pIJUbNx)

4. Арифметическая прогрессия

[Установка и пример игры](https://asciinema.org/a/dbOGsNdaL2SaeFOK8cEHX4I2j)

5. Простое ли число?

[Установка и пример игры](https://asciinema.org/a/NY5iiPpQoU2MBjvcbOn0KhpTT)