### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vlad-i-mir70/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Vlad-i-mir70/python-project-49/actions)