### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vlad-i-mir70/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Vlad-i-mir70/python-project-49/actions)
<a href="https://codeclimate.com/github/Vlad-i-mir70/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4beb700ac7eb4b5276a3/maintainability" /></a>
