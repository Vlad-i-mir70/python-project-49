#!/usr/bin/env python3

from brain_games.even_check_code import even_number


def main():
    even_number()


if __name__ == "__main__":
    main()