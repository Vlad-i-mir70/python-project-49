# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games',
 'brain_games.games',
 'brain_games.games.calc',
 'brain_games.games.even',
 'brain_games.games.gcd',
 'brain_games.games.prime',
 'brain_games.games.progression',
 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'brain-games',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Vlad-i-mir70/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Vlad-i-mir70/python-project-49/actions)\n<a href="https://codeclimate.com/github/Vlad-i-mir70/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4beb700ac7eb4b5276a3/maintainability" /></a>\n\nhttps://asciinema.org/connect/c2632bd1-75f7-4c38-86a4-2f504d480fb4\n\nhttps://asciinema.org/a/oU86oxwsoDE3RdA5LsRWaCYId\n\nhttps://asciinema.org/a/lm8qZNIo2KNJKMzUX2pIJUbNx\n\nhttps://asciinema.org/a/dbOGsNdaL2SaeFOK8cEHX4I2j',
    'author': 'y',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
